import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateEntry,
  calculateMonthlySummary,
  getAvailableMonths,
  entryToSheetRow,
  parseSheetRows,
  formatCurrency,
  REGISTER_SHEET_HEADERS,
} from './calculations.ts';
import { RegisterEntry } from '../types.ts';

test('validateEntry enforces positive amount and non-future date', () => {
  const today = '2026-10-23';

  // Future date check
  const futureEntry = {
    date: '2026-10-24',
    type: 'Expense' as const,
    headOfAccount: 'Office Expenses' as const,
    amount: 100,
    mode: 'UPI' as const,
    enteredBy: 'test@example.com',
  };
  const resFuture = validateEntry(futureEntry, today);
  assert.equal(resFuture.isValid, false);
  assert.equal(resFuture.errors.date, 'Date cannot be in the future');

  // Negative amount check
  const negEntry = {
    date: '2026-10-20',
    type: 'Expense' as const,
    headOfAccount: 'Rent' as const,
    amount: -500,
    mode: 'Bank' as const,
    enteredBy: 'test@example.com',
  };
  const resNeg = validateEntry(negEntry, today);
  assert.equal(resNeg.isValid, false);
  assert.equal(resNeg.errors.amount, 'Amount must be positive (greater than 0)');

  // Zero amount check
  const zeroEntry = {
    date: '2026-10-20',
    type: 'Income' as const,
    headOfAccount: 'Sales' as const,
    amount: 0,
    mode: 'Cash' as const,
    enteredBy: 'test@example.com',
  };
  const resZero = validateEntry(zeroEntry, today);
  assert.equal(resZero.isValid, false);
  assert.equal(resZero.errors.amount, 'Amount must be positive (greater than 0)');

  // Valid entry
  const validEntry = {
    date: '2026-10-23',
    type: 'Income' as const,
    headOfAccount: 'Professional Fees' as const,
    amount: 15000,
    mode: 'Bank' as const,
    narration: 'Consulting fees',
    enteredBy: 'Ashish Tripathi',
  };
  const resValid = validateEntry(validEntry, today);
  assert.equal(resValid.isValid, true);
  assert.deepEqual(resValid.errors, {});
});

test('calculateMonthlySummary computes income, expense, and surplus/deficit accurately', () => {
  const entries: RegisterEntry[] = [
    {
      date: '2026-10-05',
      type: 'Income',
      headOfAccount: 'Sales',
      amount: 50000,
      mode: 'Bank',
      narration: 'Product sale',
      enteredBy: 'User 1',
    },
    {
      date: '2026-10-10',
      type: 'Expense',
      headOfAccount: 'Rent',
      amount: 18000,
      mode: 'Bank',
      narration: 'Office Rent',
      enteredBy: 'User 1',
    },
    {
      date: '2026-10-15',
      type: 'Expense',
      headOfAccount: 'Utilities',
      amount: 4500,
      mode: 'UPI',
      narration: 'Electricity and internet',
      enteredBy: 'User 1',
    },
    {
      date: '2026-10-20',
      type: 'Income',
      headOfAccount: 'Interest Income',
      amount: 2500,
      mode: 'Bank',
      narration: 'FD Interest',
      enteredBy: 'User 1',
    },
    // Entry in a different month (should not affect October)
    {
      date: '2026-09-25',
      type: 'Expense',
      headOfAccount: 'Salary',
      amount: 30000,
      mode: 'Bank',
      narration: 'Sep Salary',
      enteredBy: 'User 1',
    },
  ];

  // October 2026 Summary
  const octSummary = calculateMonthlySummary(entries, '2026-10');
  assert.equal(octSummary.totalIncome, 52500); // 50000 + 2500
  assert.equal(octSummary.totalExpense, 22500); // 18000 + 4500
  assert.equal(octSummary.surplusDeficit, 30000); // 52500 - 22500
  assert.equal(octSummary.isSurplus, true);
  assert.equal(octSummary.incomeCount, 2);
  assert.equal(octSummary.expenseCount, 2);

  // Check head breakdown
  assert.equal(octSummary.byHead['Sales'].income, 50000);
  assert.equal(octSummary.byHead['Rent'].expense, 18000);
  assert.equal(octSummary.byHead['Utilities'].expense, 4500);

  // Check mode breakdown
  assert.equal(octSummary.byMode['Bank'].income, 52500);
  assert.equal(octSummary.byMode['UPI'].expense, 4500);

  // September 2026 Summary (Deficit case)
  const sepSummary = calculateMonthlySummary(entries, '2026-09');
  assert.equal(sepSummary.totalIncome, 0);
  assert.equal(sepSummary.totalExpense, 30000);
  assert.equal(sepSummary.surplusDeficit, -30000);
  assert.equal(sepSummary.isSurplus, false);
});

test('entryToSheetRow and parseSheetRows roundtrip accurately', () => {
  const originalEntry: RegisterEntry = {
    date: '2026-10-18',
    type: 'Expense',
    headOfAccount: 'Travel',
    amount: 1250.5,
    mode: 'UPI',
    narration: 'Cab to client site',
    enteredBy: 'tripathia632@gmail.com',
  };

  const row = entryToSheetRow(originalEntry);
  assert.deepEqual(row, [
    '2026-10-18',
    'Expense',
    'Travel',
    1250.5,
    'UPI',
    'Cab to client site',
    'tripathia632@gmail.com',
  ]);

  const rawRows = [
    REGISTER_SHEET_HEADERS,
    row,
  ];

  const parsed = parseSheetRows(rawRows);
  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].date, '2026-10-18');
  assert.equal(parsed[0].type, 'Expense');
  assert.equal(parsed[0].headOfAccount, 'Travel');
  assert.equal(parsed[0].amount, 1250.5);
  assert.equal(parsed[0].mode, 'UPI');
  assert.equal(parsed[0].narration, 'Cab to client site');
  assert.equal(parsed[0].enteredBy, 'tripathia632@gmail.com');
});

test('formatCurrency outputs expected notation', () => {
  assert.equal(formatCurrency(1500), 'Rs. 1,500.00');
  assert.equal(formatCurrency(-500), '-Rs. 500.00');
  assert.equal(formatCurrency(0), 'Rs. 0.00');
});

test('getAvailableMonths extracts unique sorted months', () => {
  const entries: RegisterEntry[] = [
    { date: '2026-08-10', type: 'Income', headOfAccount: 'Sales', amount: 10, mode: 'Cash', narration: '', enteredBy: '' },
    { date: '2026-10-15', type: 'Income', headOfAccount: 'Sales', amount: 10, mode: 'Cash', narration: '', enteredBy: '' },
    { date: '2026-09-01', type: 'Expense', headOfAccount: 'Rent', amount: 10, mode: 'Cash', narration: '', enteredBy: '' },
  ];
  const months = getAvailableMonths(entries, '2026-10');
  assert.deepEqual(months, ['2026-10', '2026-09', '2026-08']);
});
