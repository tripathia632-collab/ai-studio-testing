import {
  RegisterEntry,
  MonthlySummary,
  HEAD_OF_ACCOUNT_OPTIONS,
  PAYMENT_MODES,
  HeadOfAccount,
  PaymentMode,
  EntryType,
} from '../types.ts';

/**
 * Validates an entry according to user specifications:
 * - Amount must be positive (> 0)
 * - Date cannot be in the future (relative to today or provided currentDateStr)
 * - Head of Account must be a valid option
 * - Mode must be Cash, Bank, or UPI
 * - Type must be Income or Expense
 */
export function validateEntry(
  entry: Partial<RegisterEntry>,
  todayStr: string = new Date().toISOString().split('T')[0]
): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  if (!entry.date) {
    errors.date = 'Date is required';
  } else if (entry.date > todayStr) {
    errors.date = 'Date cannot be in the future';
  }

  if (entry.amount === undefined || entry.amount === null || isNaN(entry.amount)) {
    errors.amount = 'Amount is required';
  } else if (entry.amount <= 0) {
    errors.amount = 'Amount must be positive (greater than 0)';
  }

  if (!entry.type || (entry.type !== 'Income' && entry.type !== 'Expense')) {
    errors.type = 'Type must be either Income or Expense';
  }

  if (!entry.headOfAccount || !HEAD_OF_ACCOUNT_OPTIONS.includes(entry.headOfAccount as HeadOfAccount)) {
    errors.headOfAccount = 'Valid Head of Account is required';
  }

  if (!entry.mode || !PAYMENT_MODES.includes(entry.mode as PaymentMode)) {
    errors.mode = 'Payment mode must be Cash, Bank, or UPI';
  }

  if (!entry.enteredBy || entry.enteredBy.trim() === '') {
    errors.enteredBy = 'Entered By is required';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

/**
 * Formats YYYY-MM into a readable label, e.g. "2026-10" -> "October 2026"
 */
export function formatMonthLabel(monthKey: string): string {
  if (!monthKey || !monthKey.includes('-')) return monthKey;
  const [yearStr, monthStr] = monthKey.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10) - 1;
  const date = new Date(year, month, 1);
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

/**
 * Calculate total income, total expense, and surplus/deficit for a selected month (YYYY-MM).
 */
export function calculateMonthlySummary(entries: RegisterEntry[], selectedMonthKey: string): MonthlySummary {
  const byHead = {} as Record<HeadOfAccount, { income: number; expense: number }>;
  for (const head of HEAD_OF_ACCOUNT_OPTIONS) {
    byHead[head] = { income: 0, expense: 0 };
  }

  const byMode = {} as Record<PaymentMode, { income: number; expense: number }>;
  for (const mode of PAYMENT_MODES) {
    byMode[mode] = { income: 0, expense: 0 };
  }

  let totalIncome = 0;
  let totalExpense = 0;
  let incomeCount = 0;
  let expenseCount = 0;

  for (const entry of entries) {
    if (!entry.date) continue;
    const entryMonth = entry.date.substring(0, 7); // YYYY-MM
    if (entryMonth !== selectedMonthKey) continue;

    const amt = typeof entry.amount === 'number' && !isNaN(entry.amount) ? entry.amount : 0;

    if (entry.type === 'Income') {
      totalIncome += amt;
      incomeCount += 1;
      if (byHead[entry.headOfAccount]) {
        byHead[entry.headOfAccount].income += amt;
      }
      if (byMode[entry.mode]) {
        byMode[entry.mode].income += amt;
      }
    } else if (entry.type === 'Expense') {
      totalExpense += amt;
      expenseCount += 1;
      if (byHead[entry.headOfAccount]) {
        byHead[entry.headOfAccount].expense += amt;
      }
      if (byMode[entry.mode]) {
        byMode[entry.mode].expense += amt;
      }
    }
  }

  const surplusDeficit = totalIncome - totalExpense;

  return {
    monthKey: selectedMonthKey,
    monthLabel: formatMonthLabel(selectedMonthKey),
    totalIncome: Math.round(totalIncome * 100) / 100,
    totalExpense: Math.round(totalExpense * 100) / 100,
    surplusDeficit: Math.round(surplusDeficit * 100) / 100,
    isSurplus: surplusDeficit >= 0,
    incomeCount,
    expenseCount,
    byHead,
    byMode,
  };
}

/**
 * Extracts all unique YYYY-MM strings from entries plus the current month, sorted descending.
 */
export function getAvailableMonths(entries: RegisterEntry[], fallbackMonthKey: string): string[] {
  const set = new Set<string>();
  if (fallbackMonthKey) {
    set.add(fallbackMonthKey);
  }
  for (const entry of entries) {
    if (entry.date && entry.date.length >= 7) {
      set.add(entry.date.substring(0, 7));
    }
  }
  return Array.from(set).sort().reverse();
}

/**
 * Currency formatter with Indian Rupee / standard currency formatting
 */
export function formatCurrency(amount: number, currencySymbol: string = 'Rs. '): string {
  const isNegative = amount < 0;
  const absVal = Math.abs(amount);
  const formatted = absVal.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return `${isNegative ? '-' : ''}${currencySymbol}${formatted}`;
}

export const REGISTER_SHEET_HEADERS = [
  'Date',
  'Type',
  'Head of Account',
  'Amount',
  'Mode',
  'Narration',
  'Entered By',
];

/**
 * Converts a typed RegisterEntry to a Google Sheet row array
 */
export function entryToSheetRow(entry: RegisterEntry): (string | number)[] {
  return [
    entry.date,
    entry.type,
    entry.headOfAccount,
    entry.amount,
    entry.mode,
    entry.narration || '',
    entry.enteredBy || '',
  ];
}

/**
 * Parses raw 2D array from Google Sheets Register!A:G into RegisterEntry objects
 */
export function parseSheetRows(rows: (string | number)[][]): RegisterEntry[] {
  if (!rows || rows.length === 0) return [];

  // Determine if first row is header
  let startIndex = 0;
  const firstRow = rows[0];
  if (
    firstRow &&
    (firstRow[0]?.toString().toLowerCase() === 'date' ||
      firstRow[1]?.toString().toLowerCase() === 'type')
  ) {
    startIndex = 1;
  }

  const entries: RegisterEntry[] = [];

  for (let i = startIndex; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.length === 0) continue;

    const rawDate = (row[0] || '').toString().trim();
    const rawType = (row[1] || '').toString().trim();
    const rawHead = (row[2] || '').toString().trim();
    const rawAmount = row[3];
    const rawMode = (row[4] || '').toString().trim();
    const rawNarration = (row[5] || '').toString().trim();
    const rawEnteredBy = (row[6] || '').toString().trim();

    if (!rawDate && !rawAmount) continue;

    // Normalize date to YYYY-MM-DD
    let normalizedDate = rawDate;
    if (rawDate.includes('/')) {
      const parts = rawDate.split('/');
      if (parts.length === 3) {
        if (parts[0].length === 4) {
          // YYYY/MM/DD
          normalizedDate = `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
        } else if (parts[2].length === 4) {
          // DD/MM/YYYY
          normalizedDate = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
        }
      }
    }

    const type: EntryType = rawType.toLowerCase() === 'income' ? 'Income' : 'Expense';
    
    // Normalize Head of Account
    let headOfAccount: HeadOfAccount = 'Other';
    for (const opt of HEAD_OF_ACCOUNT_OPTIONS) {
      if (opt.toLowerCase() === rawHead.toLowerCase()) {
        headOfAccount = opt;
        break;
      }
    }

    // Normalize Payment Mode
    let mode: PaymentMode = 'Cash';
    for (const m of PAYMENT_MODES) {
      if (m.toLowerCase() === rawMode.toLowerCase()) {
        mode = m;
        break;
      }
    }

    const cleanedAmountStr = typeof rawAmount === 'string' ? rawAmount.replace(/[^0-9.-]/g, '') : rawAmount;
    const amount = Math.abs(parseFloat(cleanedAmountStr as string)) || 0;

    entries.push({
      id: `row-${i + 1}-${rawDate}`,
      date: normalizedDate,
      type,
      headOfAccount,
      amount,
      mode,
      narration: rawNarration,
      enteredBy: rawEnteredBy,
      rowIndex: i + 1,
    });
  }

  // Sort descending by date
  return entries.sort((a, b) => (b.date > a.date ? 1 : b.date < a.date ? -1 : 0));
}
