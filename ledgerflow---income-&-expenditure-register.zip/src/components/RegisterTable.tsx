import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Search,
  Filter,
  ArrowDownLeft,
  ArrowUpRight,
  ExternalLink,
  RefreshCw,
  Building2,
  Smartphone,
  Banknote,
  Calendar,
  UserCheck,
  Tag,
  DollarSign,
  Download,
} from 'lucide-react';
import { RegisterEntry, GoogleSpreadsheetInfo, PAYMENT_MODES, HEAD_OF_ACCOUNT_OPTIONS } from '../types.ts';
import { formatCurrency } from '../utils/calculations.ts';

interface RegisterTableProps {
  entries: RegisterEntry[];
  selectedMonth: string;
  selectedMonthLabel: string;
  spreadsheet: GoogleSpreadsheetInfo | null;
  isLoading: boolean;
  onRefresh: () => void;
}

export const RegisterTable: React.FC<RegisterTableProps> = ({
  entries,
  selectedMonth,
  selectedMonthLabel,
  spreadsheet,
  isLoading,
  onRefresh,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'All' | 'Income' | 'Expense'>('All');
  const [modeFilter, setModeFilter] = useState<string>('All');
  const [showOnlySelectedMonth, setShowOnlySelectedMonth] = useState(true);

  // Filter entries
  const filteredEntries = entries.filter((entry) => {
    if (showOnlySelectedMonth) {
      const entryMonth = entry.date.substring(0, 7);
      if (entryMonth !== selectedMonth) return false;
    }

    if (typeFilter !== 'All' && entry.type !== typeFilter) return false;
    if (modeFilter !== 'All' && entry.mode !== modeFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchNarration = entry.narration?.toLowerCase().includes(q);
      const matchHead = entry.headOfAccount?.toLowerCase().includes(q);
      const matchEnteredBy = entry.enteredBy?.toLowerCase().includes(q);
      const matchAmount = entry.amount.toString().includes(q);
      const matchDate = entry.date.includes(q);
      if (!matchNarration && !matchHead && !matchEnteredBy && !matchAmount && !matchDate) {
        return false;
      }
    }

    return true;
  });

  const exportCSV = () => {
    const headers = ['Date', 'Type', 'Head of Account', 'Amount', 'Mode', 'Narration', 'Entered By'];
    const rows = filteredEntries.map((e) => [
      `"${e.date}"`,
      `"${e.type}"`,
      `"${e.headOfAccount}"`,
      e.amount,
      `"${e.mode}"`,
      `"${(e.narration || '').replace(/"/g, '""')}"`,
      `"${(e.enteredBy || '').replace(/"/g, '""')}"`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Register_${selectedMonth}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
      {/* Table Header and Controls */}
      <div className="p-4 sm:p-5 border-b border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-bold text-lg flex items-center gap-2">
                <span>Register Sheet Records</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full font-mono bg-slate-800 text-slate-300 border border-slate-700">
                  {filteredEntries.length} {filteredEntries.length === 1 ? 'row' : 'rows'}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {showOnlySelectedMonth ? `Filtered for ${selectedMonthLabel}` : 'Showing all recorded entries'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowOnlySelectedMonth(!showOnlySelectedMonth)}
              className={`text-xs px-3 py-1.5 rounded-lg border font-medium transition-colors cursor-pointer ${
                showOnlySelectedMonth
                  ? 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
                  : 'bg-emerald-600/20 text-emerald-300 border-emerald-500/40'
              }`}
            >
              {showOnlySelectedMonth ? 'Show All Months' : 'Show Month Only'}
            </button>

            <button
              onClick={exportCSV}
              className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 transition-colors cursor-pointer"
              title="Export visible rows to CSV"
              aria-label="Export CSV"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={onRefresh}
              disabled={isLoading}
              className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 transition-colors cursor-pointer disabled:opacity-50"
              title="Refresh from Google Sheet"
              aria-label="Refresh from Google Sheet"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-emerald-400' : ''}`} />
            </button>

            {spreadsheet?.webViewLink && (
              <a
                href={spreadsheet.webViewLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/15 text-emerald-400 hover:bg-emerald-600/25 border border-emerald-500/30 text-xs font-semibold transition-colors"
                title="Open live Google Sheet"
              >
                <span>Google Sheets</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Search box */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search narration, head, user, amount..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3.5 py-2 text-slate-100 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 placeholder-slate-500"
            />
          </div>

          {/* Type Filter */}
          <div className="flex items-center space-x-1 bg-slate-800 border border-slate-700 rounded-xl p-1 text-xs">
            {(['All', 'Income', 'Expense'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTypeFilter(t)}
                className={`flex-1 py-1 px-2 rounded-lg font-medium transition-colors cursor-pointer text-center ${
                  typeFilter === t
                    ? t === 'Income'
                      ? 'bg-emerald-600 text-white'
                      : t === 'Expense'
                      ? 'bg-rose-600 text-white'
                      : 'bg-slate-700 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {/* Mode Filter */}
          <div>
            <select
              value={modeFilter}
              onChange={(e) => setModeFilter(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/50 cursor-pointer"
              aria-label="Filter by payment mode"
            >
              <option value="All">All Modes (Cash, Bank, UPI)</option>
              {PAYMENT_MODES.map((m) => (
                <option key={m} value={m}>
                  Mode: {m}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-950/70 border-b border-slate-800 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            <tr>
              <th className="py-3.5 px-4">Date</th>
              <th className="py-3.5 px-4">Type</th>
              <th className="py-3.5 px-4">Head of Account</th>
              <th className="py-3.5 px-4 text-right">Amount</th>
              <th className="py-3.5 px-4">Mode</th>
              <th className="py-3.5 px-4">Narration</th>
              <th className="py-3.5 px-4">Entered By</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {filteredEntries.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-slate-400">
                  <FileSpreadsheet className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                  <p className="font-semibold text-slate-300">No entries found</p>
                  <p className="text-xs text-slate-500 mt-1">
                    {entries.length === 0
                      ? 'No transactions recorded yet in the Register sheet'
                      : 'No transactions match the selected filters'}
                  </p>
                </td>
              </tr>
            ) : (
              filteredEntries.map((entry, idx) => (
                <tr
                  key={entry.id || `entry-${idx}`}
                  className="hover:bg-slate-800/50 transition-colors group"
                >
                  {/* Date */}
                  <td className="py-3.5 px-4 whitespace-nowrap font-mono text-slate-200">
                    {entry.date}
                  </td>

                  {/* Type */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] tracking-wider ${
                        entry.type === 'Income'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {entry.type === 'Income' ? (
                        <ArrowDownLeft className="w-3 h-3" />
                      ) : (
                        <ArrowUpRight className="w-3 h-3" />
                      )}
                      <span>{entry.type}</span>
                    </span>
                  </td>

                  {/* Head of Account */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className="font-medium text-slate-200 bg-slate-800 px-2 py-1 rounded-md border border-slate-700/60">
                      {entry.headOfAccount}
                    </span>
                  </td>

                  {/* Amount */}
                  <td className="py-3.5 px-4 whitespace-nowrap text-right font-mono font-bold text-sm">
                    <span
                      className={
                        entry.type === 'Income' ? 'text-emerald-400' : 'text-rose-400'
                      }
                    >
                      {entry.type === 'Income' ? '+' : '-'}
                      {formatCurrency(entry.amount)}
                    </span>
                  </td>

                  {/* Mode */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className="inline-flex items-center space-x-1 text-slate-300">
                      {entry.mode === 'Cash' && <Banknote className="w-3.5 h-3.5 text-amber-400" />}
                      {entry.mode === 'Bank' && <Building2 className="w-3.5 h-3.5 text-blue-400" />}
                      {entry.mode === 'UPI' && <Smartphone className="w-3.5 h-3.5 text-emerald-400" />}
                      <span className="font-medium">{entry.mode}</span>
                    </span>
                  </td>

                  {/* Narration */}
                  <td className="py-3.5 px-4 text-slate-300 max-w-xs truncate" title={entry.narration}>
                    {entry.narration || <span className="text-slate-600 italic">—</span>}
                  </td>

                  {/* Entered By */}
                  <td className="py-3.5 px-4 whitespace-nowrap text-slate-400">
                    <div className="flex items-center space-x-1.5">
                      <UserCheck className="w-3 h-3 text-emerald-400" />
                      <span className="font-medium text-slate-300 truncate max-w-[150px]">
                        {entry.enteredBy || 'Anonymous'}
                      </span>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
