import React from 'react';
import {
  AlertTriangle,
  FileSpreadsheet,
  Calendar,
  Tag,
  DollarSign,
  CreditCard,
  FileText,
  UserCheck,
  CheckCircle2,
  X,
} from 'lucide-react';
import { RegisterEntry, GoogleSpreadsheetInfo } from '../types.ts';
import { formatCurrency } from '../utils/calculations.ts';

interface ConfirmEntryModalProps {
  isOpen: boolean;
  entry: RegisterEntry | null;
  spreadsheet: GoogleSpreadsheetInfo | null;
  isSaving: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmEntryModal: React.FC<ConfirmEntryModalProps> = ({
  isOpen,
  entry,
  spreadsheet,
  isSaving,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen || !entry) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onCancel}
          disabled={isSaving}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-4">
          <div className="p-3 bg-emerald-500/15 text-emerald-400 rounded-xl">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-white font-bold text-lg">Confirm Recording Entry</h3>
            <p className="text-xs text-slate-400">
              This will append a new row to your Google Sheet <span className="text-emerald-400 font-semibold">Register</span> tab
            </p>
          </div>
        </div>

        {/* Target Spreadsheet Destination */}
        <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3 mb-4 flex items-center justify-between text-xs">
          <span className="text-slate-400">Target Spreadsheet:</span>
          <span className="text-emerald-400 font-semibold truncate max-w-[240px]">
            {spreadsheet?.name || 'Local Register (Demo)'}
          </span>
        </div>

        {/* Transaction Summary Card */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3 mb-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs text-slate-400">Type</span>
            <span
              className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase ${
                entry.type === 'Income'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
              }`}
            >
              {entry.type}
            </span>
          </div>

          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs text-slate-400 flex items-center gap-1.5">
              <DollarSign className="w-3.5 h-3.5" /> Amount
            </span>
            <span
              className={`text-lg font-bold font-mono ${
                entry.type === 'Income' ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {formatCurrency(entry.amount)}
            </span>
          </div>

          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs text-slate-400 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" /> Date
            </span>
            <span className="text-xs font-medium text-slate-200">{entry.date}</span>
          </div>

          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs text-slate-400 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5" /> Head of Account
            </span>
            <span className="text-xs font-semibold text-slate-200">{entry.headOfAccount}</span>
          </div>

          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs text-slate-400 flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5" /> Payment Mode
            </span>
            <span className="text-xs font-semibold text-slate-200">{entry.mode}</span>
          </div>

          {entry.narration && (
            <div className="flex items-start justify-between border-b border-slate-800 pb-2">
              <span className="text-xs text-slate-400 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" /> Narration
              </span>
              <span className="text-xs text-slate-300 text-right max-w-[200px] break-words">
                {entry.narration}
              </span>
            </div>
          )}

          <div className="flex items-center justify-between pt-1">
            <span className="text-xs text-slate-400 flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5" /> Entered By
            </span>
            <span className="text-xs font-semibold text-emerald-300">{entry.enteredBy}</span>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-end space-x-3">
          <button
            type="button"
            onClick={onCancel}
            disabled={isSaving}
            className="px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800 text-sm font-medium transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={isSaving}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-950/40 transition-all flex items-center space-x-2 cursor-pointer disabled:opacity-50"
          >
            {isSaving ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Writing to Google Sheet...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirm & Record</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
