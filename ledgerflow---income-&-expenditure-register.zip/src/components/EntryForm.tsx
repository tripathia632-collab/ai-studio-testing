import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import {
  PlusCircle,
  AlertCircle,
  Calendar,
  DollarSign,
  Tag,
  CreditCard,
  FileText,
  UserCheck,
  Building2,
  Smartphone,
  Banknote,
  ArrowDownLeft,
  ArrowUpRight,
  Sparkles,
} from 'lucide-react';
import {
  RegisterEntry,
  EntryType,
  HeadOfAccount,
  PaymentMode,
  HEAD_OF_ACCOUNT_OPTIONS,
  PAYMENT_MODES,
} from '../types.ts';
import { validateEntry } from '../utils/calculations.ts';

interface EntryFormProps {
  user: User | null;
  defaultEnteredBy: string;
  isSaving: boolean;
  onSubmit: (entry: RegisterEntry) => void;
}

export const EntryForm: React.FC<EntryFormProps> = ({
  user,
  defaultEnteredBy,
  isSaving,
  onSubmit,
}) => {
  // Current local date in YYYY-MM-DD
  const getTodayStr = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const todayStr = getTodayStr();

  const [date, setDate] = useState<string>(todayStr);
  const [type, setType] = useState<EntryType>('Expense');
  const [headOfAccount, setHeadOfAccount] = useState<HeadOfAccount>('Office Expenses');
  const [amountStr, setAmountStr] = useState<string>('');
  const [mode, setMode] = useState<PaymentMode>('Bank');
  const [narration, setNarration] = useState<string>('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  // Auto-fill Entered By with signed in user's display name or email
  const enteredBy = user?.displayName || user?.email || defaultEnteredBy || 'Signed-in User';

  // Set intuitive default head when type toggles if current head doesn't match common intent
  const handleTypeChange = (newType: EntryType) => {
    setType(newType);
    if (newType === 'Income') {
      if (headOfAccount === 'Rent' || headOfAccount === 'Salary' || headOfAccount === 'Office Expenses' || headOfAccount === 'Utilities' || headOfAccount === 'Travel') {
        setHeadOfAccount('Sales');
      }
    } else {
      if (headOfAccount === 'Sales' || headOfAccount === 'Professional Fees' || headOfAccount === 'Interest Income') {
        setHeadOfAccount('Office Expenses');
      }
    }
  };

  // Live validation on change
  const runValidation = (newValues?: {
    date?: string;
    amount?: number;
    type?: EntryType;
    headOfAccount?: HeadOfAccount;
    mode?: PaymentMode;
  }) => {
    const amt = newValues?.amount !== undefined ? newValues.amount : parseFloat(amountStr);
    const d = newValues?.date !== undefined ? newValues.date : date;
    const t = newValues?.type !== undefined ? newValues.type : type;
    const h = newValues?.headOfAccount !== undefined ? newValues.headOfAccount : headOfAccount;
    const m = newValues?.mode !== undefined ? newValues.mode : mode;

    const res = validateEntry(
      {
        date: d,
        amount: amt,
        type: t,
        headOfAccount: h,
        mode: m,
        enteredBy,
      },
      todayStr
    );
    setErrors(res.errors);
    return res.isValid;
  };

  const handleDateChange = (val: string) => {
    setDate(val);
    setTouched((prev) => ({ ...prev, date: true }));
    runValidation({ date: val });
  };

  const handleAmountChange = (val: string) => {
    setAmountStr(val);
    setTouched((prev) => ({ ...prev, amount: true }));
    runValidation({ amount: parseFloat(val) });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTouched({
      date: true,
      amount: true,
      type: true,
      headOfAccount: true,
      mode: true,
    });

    const parsedAmount = parseFloat(amountStr);
    const candidateEntry: RegisterEntry = {
      date,
      type,
      headOfAccount,
      amount: parsedAmount,
      mode,
      narration: narration.trim(),
      enteredBy,
    };

    const validation = validateEntry(candidateEntry, todayStr);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    onSubmit(candidateEntry);

    // Reset form fields except date and mode
    setAmountStr('');
    setNarration('');
    setTouched({});
    setErrors({});
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl">
      <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <PlusCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-white font-semibold text-lg">New Transaction Entry</h3>
            <p className="text-xs text-slate-400">
              Appends directly to your Google Sheet <code className="text-emerald-400 font-mono">Register</code> tab
            </p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5" noValidate>
        {/* Type Toggle: Income vs Expense */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
            Transaction Type <span className="text-rose-400">*</span>
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => handleTypeChange('Income')}
              className={`flex items-center justify-center space-x-2 py-3 px-4 rounded-xl font-bold text-sm border transition-all cursor-pointer ${
                type === 'Income'
                  ? 'bg-emerald-600 text-white border-emerald-500 shadow-lg shadow-emerald-950/40'
                  : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <ArrowDownLeft className="w-4 h-4" />
              <span>Income</span>
            </button>

            <button
              type="button"
              onClick={() => handleTypeChange('Expense')}
              className={`flex items-center justify-center space-x-2 py-3 px-4 rounded-xl font-bold text-sm border transition-all cursor-pointer ${
                type === 'Expense'
                  ? 'bg-rose-600 text-white border-rose-500 shadow-lg shadow-rose-950/40'
                  : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>Expense</span>
            </button>
          </div>
        </div>

        {/* Date & Amount Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Date */}
          <div>
            <label
              htmlFor="entry-date"
              className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center justify-between"
            >
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                Date <span className="text-rose-400">*</span>
              </span>
              <span className="text-[11px] font-normal text-slate-400">Cannot be future</span>
            </label>
            <input
              id="entry-date"
              type="date"
              max={todayStr}
              value={date}
              onChange={(e) => handleDateChange(e.target.value)}
              className={`w-full bg-slate-800 border rounded-xl px-3.5 py-2.5 text-slate-100 text-sm focus:outline-none focus:ring-2 transition-colors ${
                touched.date && errors.date
                  ? 'border-rose-500 focus:ring-rose-500/50'
                  : 'border-slate-700 focus:ring-emerald-500/50 focus:border-emerald-500'
              }`}
            />
            {touched.date && errors.date && (
              <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                <span>{errors.date}</span>
              </p>
            )}
          </div>

          {/* Amount */}
          <div>
            <label
              htmlFor="entry-amount"
              className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center justify-between"
            >
              <span className="flex items-center gap-1.5">
                <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                Amount <span className="text-rose-400">*</span>
              </span>
              <span className="text-[11px] font-normal text-slate-400">Positive only</span>
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs font-mono">
                Rs.
              </span>
              <input
                id="entry-amount"
                type="number"
                step="0.01"
                min="0.01"
                placeholder="0.00"
                value={amountStr}
                onChange={(e) => handleAmountChange(e.target.value)}
                className={`w-full bg-slate-800 border rounded-xl pl-10 pr-3.5 py-2.5 text-slate-100 font-mono text-sm focus:outline-none focus:ring-2 transition-colors ${
                  touched.amount && errors.amount
                    ? 'border-rose-500 focus:ring-rose-500/50'
                    : 'border-slate-700 focus:ring-emerald-500/50 focus:border-emerald-500'
                }`}
              />
            </div>
            {touched.amount && errors.amount && (
              <p className="mt-1 text-xs text-rose-400 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                <span>{errors.amount}</span>
              </p>
            )}
          </div>
        </div>

        {/* Head of Account & Payment Mode */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Head of Account */}
          <div>
            <label
              htmlFor="entry-head"
              className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5"
            >
              <Tag className="w-3.5 h-3.5 text-slate-400" />
              Head of Account <span className="text-rose-400">*</span>
            </label>
            <select
              id="entry-head"
              value={headOfAccount}
              onChange={(e) => setHeadOfAccount(e.target.value as HeadOfAccount)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 cursor-pointer"
            >
              {HEAD_OF_ACCOUNT_OPTIONS.map((head) => (
                <option key={head} value={head}>
                  {head}
                </option>
              ))}
            </select>
          </div>

          {/* Mode (Cash, Bank, UPI) */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-slate-400" />
              Mode of Payment <span className="text-rose-400">*</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {PAYMENT_MODES.map((m) => {
                const isSelected = mode === m;
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMode(m)}
                    className={`flex items-center justify-center space-x-1.5 py-2.5 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-700 text-emerald-300 border-emerald-500/60 shadow-sm'
                        : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-300'
                    }`}
                  >
                    {m === 'Cash' && <Banknote className="w-3.5 h-3.5 text-amber-400" />}
                    {m === 'Bank' && <Building2 className="w-3.5 h-3.5 text-blue-400" />}
                    {m === 'UPI' && <Smartphone className="w-3.5 h-3.5 text-emerald-400" />}
                    <span>{m}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Narration */}
        <div>
          <label
            htmlFor="entry-narration"
            className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5"
          >
            <FileText className="w-3.5 h-3.5 text-slate-400" />
            Narration / Description
          </label>
          <input
            id="entry-narration"
            type="text"
            placeholder="e.g. Office electricity bill, Client retainer, travel taxi..."
            value={narration}
            onChange={(e) => setNarration(e.target.value)}
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 placeholder-slate-500"
          />
        </div>

        {/* Entered By (Prefilled with signed in user) */}
        <div className="bg-slate-800/50 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs text-slate-400">
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span>Entered By (Signed-in user):</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-semibold text-emerald-300 bg-emerald-950/60 border border-emerald-800/50 px-2.5 py-1 rounded-md">
              {enteredBy}
            </span>
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isSaving}
          className="w-full py-3.5 px-4 rounded-xl font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-emerald-900/30 transition-all flex items-center justify-center space-x-2 cursor-pointer"
        >
          {isSaving ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Saving to Register Sheet...</span>
            </>
          ) : (
            <>
              <PlusCircle className="w-5 h-5" />
              <span>Save Entry to Register Sheet</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};
