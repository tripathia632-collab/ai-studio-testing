import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Plus,
  Search,
  ExternalLink,
  Check,
  RefreshCw,
  X,
  AlertCircle,
  FileCheck,
} from 'lucide-react';
import { GoogleSpreadsheetInfo } from '../types.ts';
import {
  listSpreadsheets,
  createSpreadsheet,
  ensureRegisterSheet,
  extractSpreadsheetId,
} from '../services/googleSheets.ts';

interface SpreadsheetSelectorModalProps {
  isOpen: boolean;
  accessToken: string | null;
  currentSpreadsheet: GoogleSpreadsheetInfo | null;
  onSelectSpreadsheet: (sheet: GoogleSpreadsheetInfo) => void;
  onClose: () => void;
}

export const SpreadsheetSelectorModal: React.FC<SpreadsheetSelectorModalProps> = ({
  isOpen,
  accessToken,
  currentSpreadsheet,
  onSelectSpreadsheet,
  onClose,
}) => {
  const [spreadsheets, setSpreadsheets] = useState<GoogleSpreadsheetInfo[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [newSheetTitle, setNewSheetTitle] = useState('Income & Expense Register');
  const [customInput, setCustomInput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (isOpen && accessToken) {
      loadSpreadsheets();
    }
  }, [isOpen, accessToken]);

  const loadSpreadsheets = async () => {
    if (!accessToken) return;
    setIsLoading(true);
    setError(null);
    try {
      const list = await listSpreadsheets(accessToken);
      setSpreadsheets(list);
    } catch (err: any) {
      console.error('Error listing sheets:', err);
      setError(err?.message || 'Failed to list spreadsheets from Google Drive');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateNew = async () => {
    if (!accessToken) return;
    setIsCreating(true);
    setError(null);
    try {
      const created = await createSpreadsheet(accessToken, newSheetTitle.trim() || 'Income & Expense Register');
      onSelectSpreadsheet(created);
      onClose();
    } catch (err: any) {
      console.error('Error creating spreadsheet:', err);
      setError(err?.message || 'Failed to create spreadsheet');
    } finally {
      setIsCreating(false);
    }
  };

  const handleSelect = async (sheet: GoogleSpreadsheetInfo) => {
    if (!accessToken) return;
    setIsLoading(true);
    setError(null);
    try {
      await ensureRegisterSheet(accessToken, sheet.id);
      onSelectSpreadsheet(sheet);
      onClose();
    } catch (err: any) {
      console.error('Error verifying Register sheet:', err);
      setError(err?.message || 'Failed to initialize Register sheet in the selected file');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCustomSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = extractSpreadsheetId(customInput);
    if (!id) {
      setError('Invalid Google Sheet URL or ID');
      return;
    }
    if (!accessToken) return;

    setIsLoading(true);
    setError(null);
    try {
      const res = await ensureRegisterSheet(accessToken, id);
      onSelectSpreadsheet({
        id,
        name: res.title,
        webViewLink: `https://docs.google.com/spreadsheets/d/${id}/edit`,
      });
      onClose();
    } catch (err: any) {
      console.error('Error loading custom sheet:', err);
      setError(err?.message || 'Could not access spreadsheet. Please check link and permissions.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  const filteredSheets = spreadsheets.filter((s) =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-2xl w-full p-6 shadow-2xl relative max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-500/15 text-emerald-400 rounded-xl">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-white font-bold text-lg">Connect Google Sheet</h3>
              <p className="text-xs text-slate-400">
                Entries will be recorded to the <code className="text-emerald-400 font-mono">Register</code> tab
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="flex-1 overflow-y-auto py-4 space-y-6">
          {/* Quick Action: Create New Sheet */}
          <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-4">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-2 flex items-center gap-1.5">
              <Plus className="w-4 h-4" /> Option 1: Create a Brand New Register Sheet
            </h4>
            <div className="flex flex-col sm:flex-row items-center gap-2 mt-2">
              <input
                type="text"
                value={newSheetTitle}
                onChange={(e) => setNewSheetTitle(e.target.value)}
                placeholder="Spreadsheet Name"
                className="w-full sm:flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                onClick={handleCreateNew}
                disabled={isCreating}
                className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl transition-all shadow-md flex items-center justify-center space-x-1.5 cursor-pointer disabled:opacity-50"
              >
                {isCreating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Creating...</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span>Create & Connect</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Paste URL or ID */}
          <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-4">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
              Option 2: Paste Google Sheet Link or ID
            </h4>
            <form onSubmit={handleCustomSubmit} className="flex flex-col sm:flex-row items-center gap-2">
              <input
                type="text"
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                placeholder="https://docs.google.com/spreadsheets/d/1abc.../edit"
                className="w-full sm:flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-xs"
              />
              <button
                type="submit"
                disabled={!customInput.trim() || isLoading}
                className="w-full sm:w-auto px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-100 font-semibold text-sm rounded-xl transition-colors cursor-pointer disabled:opacity-50"
              >
                Connect
              </button>
            </form>
          </div>

          {/* Drive Spreadsheets List */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-emerald-400" /> Option 3: Select from Google Drive
              </h4>
              <button
                onClick={loadSpreadsheets}
                disabled={isLoading}
                className="text-xs text-slate-400 hover:text-emerald-400 flex items-center gap-1 cursor-pointer transition-colors"
                title="Refresh Drive files"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            </div>

            {/* Search filter */}
            <div className="relative mb-3">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search spreadsheets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3.5 py-2 text-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {isLoading && spreadsheets.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-sm flex flex-col items-center justify-center space-y-2">
                <RefreshCw className="w-6 h-6 animate-spin text-emerald-400" />
                <span>Listing spreadsheets from your Drive...</span>
              </div>
            ) : filteredSheets.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-sm bg-slate-800/30 rounded-xl border border-slate-800">
                No spreadsheets found matching "{searchQuery}"
              </div>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {filteredSheets.map((sheet) => {
                  const isCurrent = currentSpreadsheet?.id === sheet.id;
                  return (
                    <div
                      key={sheet.id}
                      onClick={() => handleSelect(sheet)}
                      className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                        isCurrent
                          ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                          : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800 hover:border-slate-600 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center space-x-3 overflow-hidden">
                        <FileSpreadsheet
                          className={`w-5 h-5 flex-shrink-0 ${
                            isCurrent ? 'text-emerald-400' : 'text-slate-400'
                          }`}
                        />
                        <div className="truncate">
                          <p className="text-sm font-semibold truncate">{sheet.name}</p>
                          <p className="text-[11px] text-slate-400 font-mono truncate">ID: {sheet.id}</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        {isCurrent ? (
                          <span className="flex items-center space-x-1 text-xs text-emerald-400 font-bold bg-emerald-500/20 px-2 py-0.5 rounded-full">
                            <Check className="w-3.5 h-3.5" />
                            <span>Active</span>
                          </span>
                        ) : (
                          <span className="text-xs text-slate-400 bg-slate-700 px-2.5 py-1 rounded-lg">
                            Select
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
