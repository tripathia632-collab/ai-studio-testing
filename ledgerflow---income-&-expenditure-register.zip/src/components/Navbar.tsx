import React from 'react';
import { User } from 'firebase/auth';
import {
  FileSpreadsheet,
  ExternalLink,
  LogOut,
  FolderOpen,
  Sparkles,
  CheckCircle2,
  ShieldAlert,
} from 'lucide-react';
import { GoogleSpreadsheetInfo } from '../types.ts';

interface NavbarProps {
  user: User | null;
  spreadsheet: GoogleSpreadsheetInfo | null;
  isDemoMode: boolean;
  onOpenSpreadsheetModal: () => void;
  onLogin: () => void;
  onLogout: () => void;
  onToggleDemoMode: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  spreadsheet,
  isDemoMode,
  onOpenSpreadsheetModal,
  onLogin,
  onLogout,
  onToggleDemoMode,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand / Logo */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-white font-bold text-xl">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-white font-bold text-lg tracking-tight">LedgerFlow</span>
              <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                Register Sheet
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Income & Expenditure Entry connected to Google Sheets
            </p>
          </div>
        </div>

        {/* Center / Connected Sheet Status */}
        <div className="hidden md:flex items-center space-x-3">
          {spreadsheet ? (
            <div className="flex items-center space-x-2 bg-slate-800/80 border border-slate-700 px-3 py-1.5 rounded-lg text-sm">
              <FileSpreadsheet className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span className="text-slate-300 font-medium max-w-[200px] truncate" title={spreadsheet.name}>
                {spreadsheet.name}
              </span>
              <span className="text-xs text-slate-400 font-mono">/ Register</span>
              {spreadsheet.webViewLink && (
                <a
                  href={spreadsheet.webViewLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-400 hover:text-emerald-400 transition-colors p-1"
                  title="Open spreadsheet in Google Sheets"
                  aria-label="Open Google Sheet in new tab"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
              {user && (
                <button
                  onClick={onOpenSpreadsheetModal}
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-medium underline ml-1 cursor-pointer"
                >
                  Change
                </button>
              )}
            </div>
          ) : user ? (
            <button
              onClick={onOpenSpreadsheetModal}
              className="flex items-center space-x-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 px-3 py-1.5 rounded-lg text-sm transition-colors cursor-pointer"
            >
              <FolderOpen className="w-4 h-4" />
              <span>Select or Create Sheet</span>
            </button>
          ) : null}

          {isDemoMode && (
            <div className="flex items-center space-x-1.5 bg-amber-500/10 border border-amber-500/30 px-2.5 py-1 rounded-md text-amber-300 text-xs">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Preview Demo Mode</span>
            </div>
          )}
        </div>

        {/* Right Actions: User auth & Switch mode */}
        <div className="flex items-center space-x-3">
          {user ? (
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2 bg-slate-800 border border-slate-700/80 px-2.5 py-1 rounded-lg">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'User'}
                    className="w-7 h-7 rounded-full border border-slate-600"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                    {(user.displayName || user.email || 'U')[0].toUpperCase()}
                  </div>
                )}
                <div className="text-left hidden lg:block">
                  <p className="text-xs font-semibold text-slate-200 leading-tight">
                    {user.displayName || 'Google User'}
                  </p>
                  <p className="text-[11px] text-slate-400 leading-tight truncate max-w-[140px]">
                    {user.email}
                  </p>
                </div>
              </div>
              <button
                onClick={onLogout}
                className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                title="Sign out"
                aria-label="Sign out"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <button
                onClick={onToggleDemoMode}
                className={`text-xs px-3 py-2 rounded-lg font-medium transition-colors cursor-pointer ${
                  isDemoMode
                    ? 'bg-slate-800 text-slate-300 border border-slate-700'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {isDemoMode ? 'Demo Active' : 'Explore Demo'}
              </button>
              
              {/* Standard styled Google Sign in button */}
              <button
                onClick={onLogin}
                className="flex items-center space-x-2 bg-white hover:bg-slate-100 text-slate-800 font-semibold text-sm px-3.5 py-1.5 rounded-lg shadow-sm transition-all cursor-pointer"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Sign in with Google</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
