import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  ArrowDownLeft,
  ArrowUpRight,
  Wallet,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Scale,
  CreditCard,
  Building2,
  Smartphone,
  Banknote,
} from 'lucide-react';
import { MonthlySummary, PAYMENT_MODES, HEAD_OF_ACCOUNT_OPTIONS } from '../types.ts';
import { formatCurrency } from '../utils/calculations.ts';

interface MonthlySummaryCardsProps {
  summary: MonthlySummary;
  availableMonths: string[];
  selectedMonth: string;
  onSelectMonth: (month: string) => void;
}

export const MonthlySummaryCards: React.FC<MonthlySummaryCardsProps> = ({
  summary,
  availableMonths,
  selectedMonth,
  onSelectMonth,
}) => {
  const currentIdx = availableMonths.indexOf(selectedMonth);
  const hasPrev = currentIdx < availableMonths.length - 1;
  const hasNext = currentIdx > 0;

  const handlePrev = () => {
    if (hasPrev) onSelectMonth(availableMonths[currentIdx + 1]);
  };

  const handleNext = () => {
    if (hasNext) onSelectMonth(availableMonths[currentIdx - 1]);
  };

  // Savings / Surplus Rate
  const savingsRate =
    summary.totalIncome > 0
      ? Math.round((summary.surplusDeficit / summary.totalIncome) * 100)
      : summary.surplusDeficit >= 0
      ? 0
      : -100;

  return (
    <div className="space-y-4">
      {/* Month Navigator Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-white font-semibold text-base sm:text-lg flex items-center gap-2">
              <span>Monthly Overview:</span>
              <span className="text-emerald-400 font-bold">{summary.monthLabel}</span>
            </h2>
            <p className="text-xs text-slate-400">
              Aggregated from the <code className="text-emerald-400 bg-emerald-950/60 px-1 py-0.5 rounded font-mono">Register</code> sheet entries
            </p>
          </div>
        </div>

        {/* Month Selector Dropdown & Previous/Next */}
        <div className="flex items-center space-x-2">
          <button
            onClick={handlePrev}
            disabled={!hasPrev}
            className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="Previous month"
            aria-label="Previous month"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <select
            value={selectedMonth}
            onChange={(e) => onSelectMonth(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-slate-200 text-sm rounded-lg px-3 py-2 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent cursor-pointer"
            aria-label="Select month"
          >
            {availableMonths.map((m) => {
              const [y, mon] = m.split('-');
              const d = new Date(parseInt(y, 10), parseInt(mon, 10) - 1, 1);
              const label = d.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
              return (
                <option key={m} value={m}>
                  {label}
                </option>
              );
            })}
          </select>

          <button
            onClick={handleNext}
            disabled={!hasNext}
            className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="Next month"
            aria-label="Next month"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 3 Primary Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Total Income */}
        <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 to-slate-900/90 border border-emerald-900/40 rounded-2xl p-5 shadow-lg shadow-emerald-950/20">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400/90 flex items-center gap-1.5">
              <ArrowDownLeft className="w-4 h-4 text-emerald-400" />
              Total Income
            </span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-medium">
              {summary.incomeCount} {summary.incomeCount === 1 ? 'entry' : 'entries'}
            </span>
          </div>

          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400 tracking-tight">
            {formatCurrency(summary.totalIncome)}
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Inflow for {summary.monthLabel}
          </p>
        </div>

        {/* Total Expense */}
        <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 to-slate-900/90 border border-rose-900/40 rounded-2xl p-5 shadow-lg shadow-rose-950/20">
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/5 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-400/90 flex items-center gap-1.5">
              <ArrowUpRight className="w-4 h-4 text-rose-400" />
              Total Expense
            </span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-400 font-medium">
              {summary.expenseCount} {summary.expenseCount === 1 ? 'entry' : 'entries'}
            </span>
          </div>

          <div className="text-2xl sm:text-3xl font-extrabold text-rose-400 tracking-tight">
            {formatCurrency(summary.totalExpense)}
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Outflow for {summary.monthLabel}
          </p>
        </div>

        {/* Surplus or Deficit */}
        <div
          className={`relative overflow-hidden rounded-2xl p-5 border shadow-lg transition-colors ${
            summary.isSurplus
              ? 'bg-gradient-to-br from-slate-900 to-slate-900/90 border-teal-900/50 shadow-teal-950/20'
              : 'bg-gradient-to-br from-slate-900 to-slate-900/90 border-amber-900/50 shadow-amber-950/20'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span
              className={`text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 ${
                summary.isSurplus ? 'text-teal-400' : 'text-amber-400'
              }`}
            >
              <Scale className="w-4 h-4" />
              {summary.isSurplus ? 'Net Surplus' : 'Net Deficit'}
            </span>
            <span
              className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider border ${
                summary.isSurplus
                  ? 'bg-teal-500/20 text-teal-300 border-teal-500/30'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
              }`}
            >
              {summary.isSurplus ? 'Surplus' : 'Deficit'}
            </span>
          </div>

          <div
            className={`text-2xl sm:text-3xl font-extrabold tracking-tight flex items-baseline gap-2 ${
              summary.isSurplus ? 'text-teal-300' : 'text-amber-400'
            }`}
          >
            {summary.isSurplus ? '+' : ''}
            {formatCurrency(summary.surplusDeficit)}
          </div>

          <div className="mt-2 flex items-center justify-between text-xs text-slate-400">
            <span>
              {summary.isSurplus ? 'Income exceeds expenses' : 'Expenses exceed income'}
            </span>
            {summary.totalIncome > 0 && (
              <span className="font-medium text-slate-300">
                {savingsRate >= 0 ? `${savingsRate}% saved` : `${Math.abs(savingsRate)}% deficit`}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Mode Distribution Mini Pills */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <span className="text-slate-400 font-medium flex items-center gap-1.5">
          <Wallet className="w-3.5 h-3.5 text-slate-400" />
          Mode Breakdown:
        </span>
        <div className="flex flex-wrap items-center gap-3">
          {PAYMENT_MODES.map((mode) => {
            const data = summary.byMode[mode];
            const net = data.income - data.expense;
            return (
              <div
                key={mode}
                className="flex items-center space-x-2 bg-slate-800/70 border border-slate-700/60 px-2.5 py-1 rounded-lg text-slate-300"
              >
                {mode === 'Cash' && <Banknote className="w-3.5 h-3.5 text-amber-400" />}
                {mode === 'Bank' && <Building2 className="w-3.5 h-3.5 text-blue-400" />}
                {mode === 'UPI' && <Smartphone className="w-3.5 h-3.5 text-emerald-400" />}
                <span className="font-semibold text-slate-200">{mode}:</span>
                <span className="text-emerald-400 font-mono">+{formatCurrency(data.income)}</span>
                <span className="text-slate-500">/</span>
                <span className="text-rose-400 font-mono">-{formatCurrency(data.expense)}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
