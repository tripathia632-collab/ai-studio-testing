export type EntryType = 'Income' | 'Expense';

export const HEAD_OF_ACCOUNT_OPTIONS = [
  'Sales',
  'Professional Fees',
  'Interest Income',
  'Rent',
  'Salary',
  'Utilities',
  'Travel',
  'Office Expenses',
  'Other',
] as const;

export type HeadOfAccount = (typeof HEAD_OF_ACCOUNT_OPTIONS)[number];

export const PAYMENT_MODES = ['Cash', 'Bank', 'UPI'] as const;
export type PaymentMode = (typeof PAYMENT_MODES)[number];

export interface RegisterEntry {
  id?: string;
  date: string; // YYYY-MM-DD
  type: EntryType;
  headOfAccount: HeadOfAccount;
  amount: number;
  mode: PaymentMode;
  narration: string;
  enteredBy: string;
  rowIndex?: number;
}

export interface MonthlySummary {
  monthKey: string; // YYYY-MM
  monthLabel: string; // e.g. "October 2026"
  totalIncome: number;
  totalExpense: number;
  surplusDeficit: number; // income - expense
  isSurplus: boolean;
  incomeCount: number;
  expenseCount: number;
  byHead: Record<HeadOfAccount, { income: number; expense: number }>;
  byMode: Record<PaymentMode, { income: number; expense: number }>;
}

export interface GoogleSpreadsheetInfo {
  id: string;
  name: string;
  modifiedTime?: string;
  webViewLink?: string;
}
