import { RegisterEntry, GoogleSpreadsheetInfo } from '../types.ts';
import { entryToSheetRow, parseSheetRows, REGISTER_SHEET_HEADERS } from '../utils/calculations.ts';

const DRIVE_API_URL = 'https://www.googleapis.com/drive/v3';
const SHEETS_API_URL = 'https://sheets.googleapis.com/v4/spreadsheets';

/**
 * List spreadsheets from user's Google Drive
 */
export async function listSpreadsheets(accessToken: string): Promise<GoogleSpreadsheetInfo[]> {
  const query = encodeURIComponent("mimeType='application/vnd.google-apps.spreadsheet' and trashed=false");
  const url = `${DRIVE_API_URL}/files?q=${query}&fields=files(id,name,modifiedTime,webViewLink)&orderBy=modifiedTime desc&pageSize=25`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to fetch spreadsheets (${res.status})`);
  }

  const data = await res.json();
  return (data.files || []).map((f: any) => ({
    id: f.id,
    name: f.name,
    modifiedTime: f.modifiedTime,
    webViewLink: f.webViewLink || `https://docs.google.com/spreadsheets/d/${f.id}/edit`,
  }));
}

/**
 * Create a new Google Spreadsheet with a 'Register' sheet pre-formatted
 */
export async function createSpreadsheet(
  accessToken: string,
  title: string = 'Income & Expenditure Register'
): Promise<GoogleSpreadsheetInfo> {
  const body = {
    properties: {
      title,
    },
    sheets: [
      {
        properties: {
          title: 'Register',
          gridProperties: {
            frozenRowCount: 1,
          },
        },
        data: [
          {
            startRow: 0,
            startColumn: 0,
            rowData: [
              {
                values: REGISTER_SHEET_HEADERS.map((h) => ({
                  userEnteredValue: { stringValue: h },
                })),
              },
            ],
          },
        ],
      },
    ],
  };

  const res = await fetch(SHEETS_API_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to create spreadsheet (${res.status})`);
  }

  const data = await res.json();
  return {
    id: data.spreadsheetId,
    name: data.properties?.title || title,
    webViewLink: data.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${data.spreadsheetId}/edit`,
  };
}

/**
 * Verify if Register sheet exists in the spreadsheet, and create it or write headers if missing
 */
export async function ensureRegisterSheet(
  accessToken: string,
  spreadsheetId: string
): Promise<{ sheetExists: boolean; title: string }> {
  const metaRes = await fetch(`${SHEETS_API_URL}/${spreadsheetId}?fields=properties.title,sheets.properties`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!metaRes.ok) {
    const errorData = await metaRes.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to inspect spreadsheet (${metaRes.status})`);
  }

  const meta = await metaRes.json();
  const sheets: any[] = meta.sheets || [];
  const registerSheet = sheets.find(
    (s: any) => s.properties?.title?.trim().toLowerCase() === 'register'
  );

  if (!registerSheet) {
    // Add Register sheet
    const addRes = await fetch(`${SHEETS_API_URL}/${spreadsheetId}:batchUpdate`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        requests: [
          {
            addSheet: {
              properties: {
                title: 'Register',
                gridProperties: { frozenRowCount: 1 },
              },
            },
          },
        ],
      }),
    });

    if (!addRes.ok) {
      const err = await addRes.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to create Register sheet tab');
    }

    // Write header row to the newly created Register sheet
    await fetch(
      `${SHEETS_API_URL}/${spreadsheetId}/values/Register!A1:G1?valueInputOption=USER_ENTERED`,
      {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          values: [REGISTER_SHEET_HEADERS],
        }),
      }
    );
  } else {
    // Check if header row exists in Register
    const headerCheckRes = await fetch(
      `${SHEETS_API_URL}/${spreadsheetId}/values/Register!A1:G1`,
      {
        headers: { Authorization: `Bearer ${accessToken}` },
      }
    );
    if (headerCheckRes.ok) {
      const headerData = await headerCheckRes.json();
      if (!headerData.values || headerData.values.length === 0) {
        // Write header row
        await fetch(
          `${SHEETS_API_URL}/${spreadsheetId}/values/Register!A1:G1?valueInputOption=USER_ENTERED`,
          {
            method: 'PUT',
            headers: {
              Authorization: `Bearer ${accessToken}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              values: [REGISTER_SHEET_HEADERS],
            }),
          }
        );
      }
    }
  }

  return {
    sheetExists: true,
    title: meta.properties?.title || 'Google Sheet',
  };
}

/**
 * Fetch all entries from Register sheet
 */
export async function fetchRegisterEntries(
  accessToken: string,
  spreadsheetId: string
): Promise<RegisterEntry[]> {
  const range = encodeURIComponent('Register!A:G');
  const res = await fetch(`${SHEETS_API_URL}/${spreadsheetId}/values/${range}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to read Register sheet (${res.status})`);
  }

  const data = await res.json();
  const rawRows: (string | number)[][] = data.values || [];
  return parseSheetRows(rawRows);
}

/**
 * Appends a new entry to the Register sheet
 */
export async function appendRegisterEntry(
  accessToken: string,
  spreadsheetId: string,
  entry: RegisterEntry
): Promise<{ updatedRange: string }> {
  const range = encodeURIComponent('Register!A:G');
  const rowValues = entryToSheetRow(entry);

  const res = await fetch(
    `${SHEETS_API_URL}/${spreadsheetId}/values/${range}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        values: [rowValues],
      }),
    }
  );

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to save entry to Google Sheet (${res.status})`);
  }

  const data = await res.json();
  return {
    updatedRange: data.updates?.updatedRange || 'Register!A:G',
  };
}

/**
 * Extracts spreadsheet ID from Google Sheet URL or raw ID
 */
export function extractSpreadsheetId(input: string): string | null {
  if (!input) return null;
  const trimmed = input.trim();
  // Check if it's already a plain ID (alphanumeric, dashes, underscores, usually 30-50 chars)
  if (/^[a-zA-Z0-9-_]{25,60}$/.test(trimmed)) {
    return trimmed;
  }
  // Extract from Google Docs URL: /spreadsheets/d/([a-zA-Z0-9-_]+)
  const match = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (match && match[1]) {
    return match[1];
  }
  return null;
}
