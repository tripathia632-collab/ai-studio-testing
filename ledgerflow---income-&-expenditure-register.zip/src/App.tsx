/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { User } from 'firebase/auth';
import {
  FileSpreadsheet,
  PlusCircle,
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  Info,
} from 'lucide-react';
import {
  RegisterEntry,
  GoogleSpreadsheetInfo,
  MonthlySummary,
} from './types.ts';
import {
  calculateMonthlySummary,
  getAvailableMonths,
  validateEntry,
  formatCurrency,
} from './utils/calculations.ts';
import {
  initAuth,
  googleSignIn,
  logout,
  getAccessToken,
} from './firebase.ts';
import {
  fetchRegisterEntries,
  appendRegisterEntry,
  ensureRegisterSheet,
  createSpreadsheet,
  listSpreadsheets,
} from './services/googleSheets.ts';
import { INITIAL_DEMO_ENTRIES } from './data/mockData.ts';

import { Navbar } from './components/Navbar.tsx';
import { MonthlySummaryCards } from './components/MonthlySummaryCards.tsx';
import { EntryForm } from './components/EntryForm.tsx';
import { ConfirmEntryModal } from './components/ConfirmEntryModal.tsx';
import { SpreadsheetSelectorModal } from './components/SpreadsheetSelectorModal.tsx';
import { RegisterTable } from './components/RegisterTable.tsx';

const STORAGE_KEY_SHEET = 'ledgerflow_active_sheet';
const STORAGE_KEY_DEMO_ENTRIES = 'ledgerflow_demo_entries';

export default function App() {
  // Authentication state
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isAuthChecking, setIsAuthChecking] = useState(true);

  // Demo mode state (active if user is not signed in or chooses demo mode)
  const [isDemoMode, setIsDemoMode] = useState<boolean>(() => {
    return localStorage.getItem('ledgerflow_mode') === 'demo';
  });

  // Active connected spreadsheet
  const [spreadsheet, setSpreadsheet] = useState<GoogleSpreadsheetInfo | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_SHEET);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  // Entries list
  const [entries, setEntries] = useState<RegisterEntry[]>(() => {
    const savedDemo = localStorage.getItem(STORAGE_KEY_DEMO_ENTRIES);
    if (savedDemo) {
      try {
        return JSON.parse(savedDemo);
      } catch (e) {}
    }
    return INITIAL_DEMO_ENTRIES;
  });

  // Selected month (e.g. "2026-10")
  const currentMonthKey = useMemo(() => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}`;
  }, []);

  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonthKey);

  // UI state
  const [isLoadingEntries, setIsLoadingEntries] = useState(false);
  const [isSavingEntry, setIsSavingEntry] = useState(false);
  const [candidateEntry, setCandidateEntry] = useState<RegisterEntry | null>(null);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [isSheetModalOpen, setIsSheetModalOpen] = useState(false);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error' | 'info';
    message: string;
    sheetUrl?: string;
  } | null>(null);

  // Initialize Firebase Auth listener
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, token) => {
        setUser(currentUser);
        setAccessToken(token);
        setIsAuthChecking(false);
        setIsDemoMode(false);
        localStorage.removeItem('ledgerflow_mode');
      },
      () => {
        setUser(null);
        setAccessToken(null);
        setIsAuthChecking(false);
      }
    );
    return () => unsubscribe();
  }, []);

  // Fetch entries from Google Sheets when signed in with an active spreadsheet
  const loadSheetEntries = useCallback(
    async (token: string, sheetId: string) => {
      setIsLoadingEntries(true);
      try {
        const rows = await fetchRegisterEntries(token, sheetId);
        setEntries(rows);
      } catch (err: any) {
        console.error('Failed to load entries from sheet:', err);
        setNotification({
          type: 'error',
          message: err?.message || 'Failed to load entries from Google Sheet Register tab',
        });
      } finally {
        setIsLoadingEntries(false);
      }
    },
    []
  );

  // When access token or active spreadsheet changes, load sheet entries
  useEffect(() => {
    if (accessToken && spreadsheet && !isDemoMode) {
      loadSheetEntries(accessToken, spreadsheet.id);
    }
  }, [accessToken, spreadsheet, isDemoMode, loadSheetEntries]);

  // If user signs in but has no saved spreadsheet, auto-discover or suggest creating one
  useEffect(() => {
    if (accessToken && !spreadsheet && !isDemoMode) {
      (async () => {
        try {
          const list = await listSpreadsheets(accessToken);
          // Look for an existing sheet named "Income & Expense Register" or similar
          const existing = list.find((s) =>
            s.name.toLowerCase().includes('income') || s.name.toLowerCase().includes('register')
          );
          if (existing) {
            await ensureRegisterSheet(accessToken, existing.id);
            setSpreadsheet(existing);
            localStorage.setItem(STORAGE_KEY_SHEET, JSON.stringify(existing));
          } else {
            // Open sheet selection modal
            setIsSheetModalOpen(true);
          }
        } catch (e) {
          console.error('Error auto-discovering sheet:', e);
          setIsSheetModalOpen(true);
        }
      })();
    }
  }, [accessToken, spreadsheet, isDemoMode]);

  // Auth Handlers
  const handleLogin = async () => {
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setAccessToken(res.accessToken);
        setIsDemoMode(false);
        localStorage.removeItem('ledgerflow_mode');
        setNotification({
          type: 'success',
          message: `Signed in as ${res.user.displayName || res.user.email}. Connected to Google Sheets.`,
        });
      }
    } catch (err: any) {
      console.error('Login error:', err);
      setNotification({
        type: 'error',
        message: err?.message || 'Google sign-in was cancelled or failed.',
      });
    }
  };

  const handleLogout = async () => {
    await logout();
    setUser(null);
    setAccessToken(null);
    setIsDemoMode(true);
    setNotification({
      type: 'info',
      message: 'Signed out. Switched to preview demo mode.',
    });
  };

  const handleToggleDemoMode = () => {
    const nextMode = !isDemoMode;
    setIsDemoMode(nextMode);
    if (nextMode) {
      localStorage.setItem('ledgerflow_mode', 'demo');
    } else {
      localStorage.removeItem('ledgerflow_mode');
    }
  };

  const handleSelectSpreadsheet = (newSheet: GoogleSpreadsheetInfo) => {
    setSpreadsheet(newSheet);
    localStorage.setItem(STORAGE_KEY_SHEET, JSON.stringify(newSheet));
    setNotification({
      type: 'success',
      message: `Connected to "${newSheet.name}". Recording to Register tab.`,
      sheetUrl: newSheet.webViewLink,
    });
    if (accessToken) {
      loadSheetEntries(accessToken, newSheet.id);
    }
  };

  // Entry Form submission -> open explicit confirmation modal
  const handleFormSubmit = (entry: RegisterEntry) => {
    setCandidateEntry(entry);
    setIsConfirmModalOpen(true);
  };

  // Modal confirmation -> write to Google Sheet Register
  const handleConfirmRecord = async () => {
    if (!candidateEntry) return;
    setIsSavingEntry(true);

    try {
      if (isDemoMode || !accessToken || !spreadsheet) {
        // Record in local state / demo mode
        const newEntryWithId: RegisterEntry = {
          ...candidateEntry,
          id: `demo-${Date.now()}`,
          rowIndex: entries.length + 2,
        };
        const updated = [newEntryWithId, ...entries].sort((a, b) =>
          b.date > a.date ? 1 : b.date < a.date ? -1 : 0
        );
        setEntries(updated);
        localStorage.setItem(STORAGE_KEY_DEMO_ENTRIES, JSON.stringify(updated));

        // Switch selected month to entry's month if different
        const entryMonth = candidateEntry.date.substring(0, 7);
        setSelectedMonth(entryMonth);

        setNotification({
          type: 'success',
          message: `Recorded ${candidateEntry.type} of ${formatCurrency(candidateEntry.amount)} for "${candidateEntry.headOfAccount}"!`,
        });
      } else {
        // Append row to the live Google Sheet Register tab
        await appendRegisterEntry(accessToken, spreadsheet.id, candidateEntry);

        // Reload sheet entries to ensure consistency
        await loadSheetEntries(accessToken, spreadsheet.id);

        // Switch selected month to entry's month
        const entryMonth = candidateEntry.date.substring(0, 7);
        setSelectedMonth(entryMonth);

        setNotification({
          type: 'success',
          message: `Successfully saved ${candidateEntry.type} of ${formatCurrency(
            candidateEntry.amount
          )} to Google Sheet Register!`,
          sheetUrl: spreadsheet.webViewLink,
        });
      }

      setIsConfirmModalOpen(false);
      setCandidateEntry(null);
    } catch (err: any) {
      console.error('Error saving entry to sheet:', err);
      setNotification({
        type: 'error',
        message: err?.message || 'Failed to append entry to Google Sheet',
      });
    } finally {
      setIsSavingEntry(false);
    }
  };

  // Available months for selector
  const availableMonths = useMemo(() => {
    return getAvailableMonths(entries, currentMonthKey);
  }, [entries, currentMonthKey]);

  // Monthly summary calculations (pure function)
  const monthlySummary: MonthlySummary = useMemo(() => {
    return calculateMonthlySummary(entries, selectedMonth);
  }, [entries, selectedMonth]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        user={user}
        spreadsheet={spreadsheet}
        isDemoMode={isDemoMode}
        onOpenSpreadsheetModal={() => setIsSheetModalOpen(true)}
        onLogin={handleLogin}
        onLogout={handleLogout}
        onToggleDemoMode={handleToggleDemoMode}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Banner notification */}
        {notification && (
          <div
            className={`p-4 rounded-2xl flex items-center justify-between border shadow-lg transition-all animate-in fade-in duration-200 ${
              notification.type === 'success'
                ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                : notification.type === 'error'
                ? 'bg-rose-950/60 border-rose-500/40 text-rose-300'
                : 'bg-slate-900 border-slate-700 text-slate-300'
            }`}
          >
            <div className="flex items-center space-x-3">
              {notification.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              ) : notification.type === 'error' ? (
                <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0" />
              ) : (
                <Info className="w-5 h-5 text-blue-400 flex-shrink-0" />
              )}
              <span className="text-sm font-medium">{notification.message}</span>
            </div>

            <div className="flex items-center space-x-3">
              {notification.sheetUrl && (
                <a
                  href={notification.sheetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 px-3 py-1.5 rounded-lg transition-colors shadow-sm"
                >
                  <span>View in Sheets</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
              <button
                onClick={() => setNotification(null)}
                className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {/* Informative Banner when not connected to a Google Sheet */}
        {!user && isDemoMode && (
          <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/20 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-200">
                  Preview Mode Active (Local Mock Register)
                </p>
                <p className="text-xs text-slate-400">
                  Sign in with Google anytime to record entries directly into your actual Google Sheet.
                </p>
              </div>
            </div>
            <button
              onClick={handleLogin}
              className="text-xs font-bold text-slate-900 bg-white hover:bg-slate-100 px-4 py-2 rounded-xl transition-all shadow-sm cursor-pointer whitespace-nowrap"
            >
              Sign in with Google
            </button>
          </div>
        )}

        {/* Monthly Summary Cards (Income, Expense, Surplus/Deficit) */}
        <section aria-label="Monthly Financial Summary">
          <MonthlySummaryCards
            summary={monthlySummary}
            availableMonths={availableMonths}
            selectedMonth={selectedMonth}
            onSelectMonth={setSelectedMonth}
          />
        </section>

        {/* 2-Column Layout: Entry Form on Left, Register Table on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Entry Form (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <EntryForm
              user={user}
              defaultEnteredBy={user?.displayName || user?.email || 'Ashish Tripathi'}
              isSaving={isSavingEntry}
              onSubmit={handleFormSubmit}
            />

            {/* Quick Helper Box */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 text-xs text-slate-400 space-y-2">
              <div className="flex items-center space-x-2 text-slate-300 font-semibold">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Accounting & Validation Rules:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-slate-400 ml-1">
                <li><strong className="text-slate-300">Amount:</strong> Must be strictly positive (&gt; 0).</li>
                <li><strong className="text-slate-300">Date:</strong> Future dates are prohibited.</li>
                <li><strong className="text-slate-300">Entered By:</strong> Automatically filled from authenticated user.</li>
                <li><strong className="text-slate-300">Destination:</strong> Appended to the <code className="text-emerald-400 font-mono">Register</code> tab.</li>
              </ul>
            </div>
          </div>

          {/* Right Column: Register Sheet Table (7 cols) */}
          <div className="lg:col-span-7">
            <RegisterTable
              entries={entries}
              selectedMonth={selectedMonth}
              selectedMonthLabel={monthlySummary.monthLabel}
              spreadsheet={spreadsheet}
              isLoading={isLoadingEntries}
              onRefresh={() => {
                if (accessToken && spreadsheet) {
                  loadSheetEntries(accessToken, spreadsheet.id);
                } else {
                  setNotification({
                    type: 'info',
                    message: 'Refreshed local demo records.',
                  });
                }
              }}
            />
          </div>
        </div>
      </main>

      {/* Confirmation Modal prior to saving to Google Sheets */}
      <ConfirmEntryModal
        isOpen={isConfirmModalOpen}
        entry={candidateEntry}
        spreadsheet={spreadsheet}
        isSaving={isSavingEntry}
        onConfirm={handleConfirmRecord}
        onCancel={() => {
          setIsConfirmModalOpen(false);
          setCandidateEntry(null);
        }}
      />

      {/* Spreadsheet Selector / Creator Modal */}
      <SpreadsheetSelectorModal
        isOpen={isSheetModalOpen}
        accessToken={accessToken}
        currentSpreadsheet={spreadsheet}
        onSelectSpreadsheet={handleSelectSpreadsheet}
        onClose={() => setIsSheetModalOpen(false)}
      />
    </div>
  );
}
